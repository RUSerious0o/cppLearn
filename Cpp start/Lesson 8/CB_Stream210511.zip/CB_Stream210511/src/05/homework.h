#ifndef CLIONPRJ_HOMEWORK_H
#define CLIONPRJ_HOMEWORK_H

#include <iostream>

namespace sixth {
    void displayArr(int, int *);

    void displayArr(int, ...);

    void change(int, int *);

    void change2(int, ...);

    void filler(int, int *);

    bool isBalanced(int, int *);

    void shifter(int, int *, int);
}

#endif //CLIONPRJ_HOMEWORK_H
