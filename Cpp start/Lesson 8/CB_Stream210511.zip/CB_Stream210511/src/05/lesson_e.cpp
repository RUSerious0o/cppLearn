#include <iostream>

//[return value type] [name] [(parameters)] {
//    [body]
//    can not define function here!
//}

namespace printers {
    // - объявление, определение, прототип
    void funcPrint(int, int, bool=false);
}

void calc(int a, int b, int c, int d=1) {
    std::cout << a * (b + (c * 1.0 / d)) << std::endl;
}

bool check(int a, int b) {
 // - возвращаемые значения
    if (true)
        return (a + b) >= 10 && (a + b) <= 20;
    else
        return false;
}

float mean(int size, ...) {
    float result;
    va_list lst;
    va_start(lst, size);
    
    for (int i = 0; i < size; i++) {
        result += va_arg(lst, int);
    }
    
    va_end(lst);
    return result / size;
}

void divideByTwo(float* f) {
    *f = *f / 2.0f;
}

void divideByThree(float& f) {
    f = f / 3;
}

double getRect(int a, int b) {
    return a * b;
}
double getCircle(int a, int b) {
    return 3.1415926 * a * b;
}

int main(int argc, const char** argv) { // 1TBS

    double (*func[2]) (int, int);
    func[0] = getRect;
    func[1] = getCircle;
    for (int i = 0; i < 2; i++) {
        std::cout << func[i](5, 5) << std::endl;
    }


 // - понятие и необходимость
    int a = 10;
    const int b = 5;
    bool result = check(a, b);
    
 // - вызов функции, аргументы, аргументы по умолчанию
    // funcPrint(a, b, result);
    // funcPrint(a, b);
//    calc(a=1, c=2, b=3); // you can do in in python, but can't do it in C/C++
    // calc(1, 2, 3, 4);

 // - переменное число параметров
    // std::cout << mean(5, 1, 2, 3, 4, 5) << std::endl;
    // std::cout << mean(10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10) << std::endl;

 // - передача аргументов (ссылкой, указателем)
    // Car c; // black
    //paintCar(c); // red
    //deployCar(c); // black
    float var = 10;
    std::cout << var << std::endl;
    divideByTwo(&var);
    std::cout << var << std::endl;
    divideByThree(var);
    std::cout << var << std::endl;

 // - пространства имён
    printers::funcPrint(1.0f, 2.0f, true);
    using namespace printers;
    
 // - указатели на функции
    
   
    return 0; 
}

namespace printers {
 // - перегрузка функций
    void funcPrint(float a, float b, bool r) { }
    void funcPrint(int a, int b) { } // bad function overloading
    void funcPrint(bool r) { }
}

// - параметры (копированием)
void printers::funcPrint(int a, int b, bool r) {
    std::cout << "I. " << (a + b) << " -> " << r << std::endl;
}

